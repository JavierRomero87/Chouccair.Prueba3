package Chouccair.Prueba3.Model;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import Chouccair.Prueba3.PageObjects.ValidacionPageObjects;
import net.serenitybdd.core.pages.PageObjects;

public class ArchivoCSV {
	ValidacionPageObjects page;

	public void ManejoArchivo() throws IOException {

		String[] datos = null;

		String csvFile = "C:\\Users\\gromerom\\Desktop\\archivo.csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		try {
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {
				datos = line.split(cvsSplitBy);

				for (int i = 0; i < datos.length; i++) {
					String setNombrDoc = (datos[0]);
					String setApellidoDoc = (datos[1]);
					String setApellidosDoc = (datos[2]);
					String setNumeroDoc = (datos[3]);
					String setFechaErrada = (datos[4]);
					String setFecha = (datos[5]);
					
					System.out.println(setNombrDoc+ setApellidoDoc+setApellidosDoc +setNumeroDoc+ setFechaErrada + setFecha);

					page.IngresarInformacon(setNombrDoc, setApellidoDoc, setApellidosDoc, setNumeroDoc, setFechaErrada,setFecha);

				}

			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}

}
