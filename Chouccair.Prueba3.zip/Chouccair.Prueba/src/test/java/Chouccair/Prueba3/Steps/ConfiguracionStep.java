package Chouccair.Prueba3.Steps;

import java.awt.AWTException;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import org.openqa.selenium.Keys;
import Chouccair.Prueba3.Model.ArchivoCSV;
import Chouccair.Prueba3.Model.TomaPantalla;
import Chouccair.Prueba3.PageObjects.ValidacionPageObjects;
import net.thucydides.core.annotations.Step;


public class ConfiguracionStep {
	
	 public String setNombrDoc, setApellidoDoc, setApellidosDoc, setNumeroDoc, setFechaErrada,setFecha;
	
	ValidacionPageObjects page;
	
	@Step
	public void CapturaPantalla() throws AWTException, IOException {
		TomaPantalla captura = new TomaPantalla();
		page.open();
		page.PasoNueve();
		captura.CapturaPuento();
		

	}
	@Step
	public void IngresoDatos() throws IOException {

		ManejoArchivo();
		page.IngresarInformacon(setNombrDoc, setApellidoDoc, setApellidosDoc, setNumeroDoc, setFechaErrada,setFecha);
	}

	public void RegistroExitoso() {

	}
	
	
	public void ManejoArchivo() throws IOException {

		String[] datos = null;

		String csvFile = "C:\\Users\\gromerom\\Desktop\\archivo.csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		try {
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {
				datos = line.split(cvsSplitBy);

				for (int i = 0; i < datos.length; i++) {
					 setNombrDoc = (datos[0]);
					 setApellidoDoc = (datos[1]);
					 setApellidosDoc = (datos[2]);
					 setNumeroDoc = (datos[3]);
					 setFechaErrada = (datos[4]);
					 setFecha = (datos[5]);
				}

			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}
	
	
	
	
	

}
