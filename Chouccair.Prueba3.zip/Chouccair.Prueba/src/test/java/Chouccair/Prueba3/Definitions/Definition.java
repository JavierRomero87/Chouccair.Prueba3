package Chouccair.Prueba3.Definitions;

import Chouccair.Prueba3.Steps.ConfiguracionStep;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class Definition {

	@Steps
	ConfiguracionStep configuracionStep;

	@Given("^evidenciar el paso nueve de las condiciones$")
	public void evidenciar_el_paso_nueve_de_las_condiciones() throws Throwable {
		configuracionStep.CapturaPantalla();

	}

	@When("^usuario ingreso nombres, apellido ,segundo apellido, validar mas ventajas, seleccionar tipo de documento , fecha$")
	public void usuario_ingreso_nombres_apellido_segundo_apellido_validar_mas_ventajas_seleccionar_tipo_de_documento_fecha()
			throws Throwable {
		configuracionStep.IngresoDatos();
	}

	@Then("^validar transaccion exitosa$")
	public void validar_transaccion_exitosa() throws Throwable {
		configuracionStep.RegistroExitoso();

	}

}
