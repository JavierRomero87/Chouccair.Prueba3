package Chouccair.Prueba3.PageObjects;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import java.awt.AWTException;
import java.io.IOException;

import org.apache.bcel.generic.Select;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.server.handler.FindElement;

import Chouccair.Prueba3.Model.TomaPantalla;
import net.serenitybdd.core.annotations.findby.By;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("https://www.proteccion.com/wps/portal/proteccion/web/home/general/solicita-clave")

public class ValidacionPageObjects extends PageObject {

	public void PasoNueve() throws AWTException, IOException {

		findBy("//p[contains(text(),'Condiciones de uso')]").click();
		findBy("//h3[contains(text(),'Línea de servicio Protección')]").click();

	}

	public void IngresarInformacon(String nombre, String apellido, String apellidos, String numeroDoc,String fechaErrada, String fecha) {

		WebDriver driver = new ChromeDriver();
		driver.get("https://transacciones.proteccion.com/ActualizacionInformacionWEB");
		driver.manage().window().maximize();
		driver.switchTo().frame("contenido2");

		// Ingresar en un marco información en formulario
		WebElement element;
		element = driver.findElement(By.id("nombres"));
		element.sendKeys(nombre);

		element = driver.findElement(By.id("primerApellido"));
		element.sendKeys(apellido);

		element = driver.findElement(By.id("segundoApellido"));
		element.sendKeys(apellidos);

		driver.findElement(By.xpath("/html/body/div[1]/form/div[2]/ul/li[2]/a/span")).click();

		// Seleccionar Tipo documento en Marco

		// Select tipoIdentificacion = new Select
		// (driver.findElement(By.id("tipoIdentificacion")));
		// ((WebElementFacade) tipoIdentificacion).selectByVisibleText("CE");
		// tipoIdentificacion.selectByIndex(2);

		element = driver.findElement(By.id("identificacion"));
		element.sendKeys(numeroDoc);

		// Manejo Seleccionador de fecha en Marco
		
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebElement dateBox = driver.findElement(By.xpath("//*[@id=\'fechaExpedicion\']"));
		dateBox.sendKeys("24/03/2019");
		dateBox.sendKeys(Keys.TAB);

		driver.findElement(By.xpath("/html/body/div[1]/form/div[1]/div[5]/a")).click();
		driver.findElement(By.xpath("/html/body/div[4]/div[3]/div[5]/table/tbody/tr/td")).click();

	}

}
